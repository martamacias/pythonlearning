from setuptools import setup


setup(
    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Marta Macias",
    packages=["Paquete_Calculos/RedondeoYPotencia"]
)