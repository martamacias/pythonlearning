def potencia(op1,op2):
    print("Resultado potencia:", op1**op2)

def redondear(op1):
    print("El redondeo es:", round(op1))